function nextBusinessDay(tp) {
  const dow = parseInt(tp.date.now("d")); // 0=Sun, 1=Mon, ..., 6=Sat
  let offset;
  if (dow === 5) offset = 3; // Friday -> Monday
  else offset = 1;           // All other weekdays -> next day
  return tp.date.now("YYYY-MM-DD", offset);
}

module.exports = nextBusinessDay;

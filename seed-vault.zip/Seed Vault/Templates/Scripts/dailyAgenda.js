function dailyAgenda(tp) {
  const day = tp.date.now("dddd");
  const week = parseInt(tp.date.now("WW"));
  const isOddWeek = week % 2 !== 0;
  const isEvenWeek = week % 2 == 0;
  const dayOfMonth = parseInt(tp.date.now("D"));
  const daysInMonth = new Date(
    parseInt(tp.date.now("YYYY")),
    parseInt(tp.date.now("M")),  // JS Date uses 1-12 here, then wraps correctly with day 0
    0
  ).getDate();
  
  const isFirstWeekday  = dayOfMonth >= 1  && dayOfMonth <= 7;
  const isSecondWeekday = dayOfMonth >= 8  && dayOfMonth <= 14;
  const isThirdWeekday  = dayOfMonth >= 15 && dayOfMonth <= 21;
  const isLastWeekday   = dayOfMonth + 7 > daysInMonth;

  const lines = [];

  // ── Monday ──────────────────────────────────────────────────────────────────
  if (day === "Monday") {
    lines.push("- [ ] 1000 [[Team]] [[huddle]]");
    lines.push("- 1700 [[Cancelled]]");

  // ── Tuesday ─────────────────────────────────────────────────────────────────
  } else if (day === "Tuesday") {
    if (isOddWeek) {
      lines.push("- [ ] 1100 [[Partner Person]]");
    }
    lines.push("- [ ] 1200 Lunch");

  // ── Wednesday ───────────────────────────────────────────────────────────────
  } else if (day === "Wednesday") {
    lines.push("- [ ] 1100 [[One-on-One with Manager]]");
    if (isEvenWeek) {
    	lines.push("- [ ] 1230 [[Long and Complex Focus Area|Shorthand]]");
    }

  // ── Thursday ────────────────────────────────────────────────────────────────
  } else if (day === "Thursday") {
    lines.push("- [ ] 1100 [[Design Review]] [[weekly]]");

  // ── Friday ──────────────────────────────────────────────────────────────────
  } else if (day === "Friday") {
    lines.push("- [ ] 1500 [[Weekly]] [[wind down]]");

  // ── Weekend / no recurring meetings ─────────────────────────────────────────
  } else {
    lines.push("- [ ] ");
  }

  return lines.join("\n");
}

module.exports = dailyAgenda;

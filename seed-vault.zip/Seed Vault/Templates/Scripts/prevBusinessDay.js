function prevBusinessDay(tp) {
  const dow = parseInt(tp.date.now("d")); // 0=Sun, 1=Mon, ..., 6=Sat
  let offset;
  if (dow === 1) offset = -3; // Monday -> Friday
  else offset = -1;           // All other weekdays -> previous day
  return tp.date.now("YYYY-MM-DD", offset);
}

module.exports = prevBusinessDay;

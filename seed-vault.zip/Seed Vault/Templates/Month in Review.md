<%* await tp.file.move("Notes/Monthly/" + tp.file.title) -%>
---
tags:
- MonthInReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% moment().subtract(1,'months').format("gggg-MM") %>|Last month]] | [[<% moment().add(1,'months').format("gggg-MM") %>|Next month]]
# Summary Insights

—  [[<% tp.date.now("YYYY-MM-DD") %>]] at <% tp.date.now("HH:mm") %>
# Notes
- 

# To Do
## Done
```tasks
done
# done this month
done in <% tp.date.now("YYYY-MM") %>
```
# Not done
```tasks
not done
happens before tomorrow
sort by urgency
```
# Weekly notes
- [[<% moment().add(1,'weeks').format("gggg-[W]ww") %>]] 
- [[<% moment().add(2,'weeks').format("gggg-[W]ww") %>]] 
- [[<% moment().add(3,'weeks').format("gggg-[W]ww") %>]] 
- [[<% moment().add(4,'weeks').format("gggg-[W]ww") %>]] 
- [[<% moment().add(5,'weeks').format("gggg-[W]ww") %>]] 
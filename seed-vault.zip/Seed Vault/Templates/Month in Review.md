<%* await tp.file.move("Notes/Monthly/" + tp.file.title) -%>
---
tags:
- MonthInReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% tp.date.now("gggg-MM", -1, "month") %>|Last month]] | [[<% tp.date.now("gggg-MM", 1, "month") %>|Next month]]
# Summary Insights

—  [[<% tp.date.now("YYYY-MM-DD") %>]] at <% tp.date.now("HH:mm") %>
# Notes
- 

# To Do
## Done
```tasks
done
# done this month
done in <% tp.date.now("YYYY-MM") %>
```
# Not done
```tasks
not done
happens before tomorrow
sort by urgency
```
# Weekly notes
- [[<% tp.date.now("gggg-[W]ww", 1, "week") %>]] 
- [[<% tp.date.now("gggg-[W]ww", 2, "week") %>]] 
- [[<% tp.date.now("gggg-[W]ww", 3, "week") %>]] 
- [[<% tp.date.now("gggg-[W]ww", 4, "week") %>]] 
- [[<% tp.date.now("gggg-[W]ww", 5, "week") %>]] 
<%* await tp.file.move("Notes/Yearly/" + tp.file.title) -%>
---
tags:
- YearInReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% tp.date.now("gggg", -1, "year") %>|Last year]] | [[<% tp.date.now("gggg", 1, "year") %>|Next year]]

# Summary Insights
- 

—  [[<% tp.date.now("gggg-MM-DD") %>]] at <% tp.date.now("HH:mm") %>

# Quarterly notes
- [[<% tp.date.now("gggg-[Q]Q", -12, "month") %>]]
- [[<% tp.date.now("gggg-[Q]Q", -9, "month") %>]]
- [[<% tp.date.now("gggg-[Q]Q", -6, "month") %>]]
- [[<% tp.date.now("gggg-[Q]Q", -3, "month") %>]]
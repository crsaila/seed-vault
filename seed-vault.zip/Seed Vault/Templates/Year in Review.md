<%* await tp.file.move("Notes/Yearly/" + tp.file.title) -%>
---
tags:
- YearInReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% moment().subtract(1,'years').format("gggg") %>|Last year]] | [[<% moment().add(1,'years').format("gggg") %>|Next year]]

# Summary Insights
- 

—  [[<% tp.date.now("gggg-MM-DD") %>]] at <% tp.date.now("HH:mm") %>

# Quarterly notes
- [[<% moment().subtract(12,'months').format("gggg-[Q]Q") %>]]
- [[<% moment().subtract(9,'months').format("gggg-[Q]Q") %>]]
- [[<% moment().subtract(6,'months').format("gggg-[Q]Q") %>]]
- [[<% moment().subtract(3,'months').format("gggg-[Q]Q") %>]]
<%* await tp.file.move("Notes/Quarterly/" + tp.file.title) -%>
---
aliases: 
tags:
  - QuarterlyReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% moment().subtract(3,'months').format("gggg-[Q]Q") %>|Last quarter]] | [[<% moment().add(3,'months').format("gggg-[Q]Q") %>|Next quarter]] | [[<% tp.date.now("gggg") %>|Year of…]]  (*calendar-based*)
# Summary Insights


—  [[<% tp.date.now("gggg-MM-DD") %>]] at <% tp.date.now("HH:mm") %>

## What went well
> [!info]- Remember
> Include metrics of success
- 

## What to improve
> [!warning]- Don’t forget
> Add these as goals for next quarter
- 

## What to continue
- 

# Unaddressed opportunities
```dataview
TASK
FROM "3 Resources and curiosities/List of opportunities"
WHERE !completed 
SORT rows.file.ctime ASC
```
# Unaddressed questions
```dataview
TASK
FROM "3 Resources and curiosities/List of questions"
WHERE !completed 
SORT rows.file.ctime ASC
```

# To Review
```query
tag:ReviewThis -tag:ignore -tag:WeekInReview
```

# Monthly notes
- Month 3: [[<% tp.date.now("gggg-MM") %>]]
- Month 2: [[<% moment().subtract(1,'months').format("gggg-MM") %>]]
- Month 1: [[<% moment().subtract(2,'months').format("gggg-MM") %>]]
---
tags:
  - MOC
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date:
---

# Overview

# References
## Backlinks
```dataview
list from [[<% tp.file.title %>]] and !outgoing([[<% tp.file.title %>]])
```
## Tagged
==(Update keyword)==
```dataview
LIST
FROM #<% tp.file.title %> AND -#MOC
```

## Text references
```query
content:"<% tp.file.title %>" -(content:"[[<% tp.file.title %>]]") -(tag:MOC)
```

***
# See also
- 
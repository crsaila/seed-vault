---
tags:
  - DailyNote
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date:
---
[[<% tp.user.prevBusinessDay(tp) %>|Previous day]] | [[<% tp.user.nextBusinessDay(tp) %>|Next day]] | [[<% tp.date.now("gggg-[W]WW") %>|Week of…]]
# Agenda
<% tp.user.dailyAgenda(tp) %>

<!-- Replace with your own AI briefer link, or remove this line -->
# To do
```tasks
not done
happens before tomorrow
sort by urgency
```

# Notes
- 

***
# See also: 
- 
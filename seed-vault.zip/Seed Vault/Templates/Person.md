---
aliases: 
pronouns: 
tags:
  - person
  - bio
role: 
team: 
sub-product: 
product: 
department: 
division: 
location: 
birthday: 
start_date: 
saved_date: <% tp.date.now("YYYY-MM-DD") %> 
updated_date: <% tp.date.now("YYYY-MM-DD") %>
---

# Notes


# Biography


# Connections
- **Manager**:
- **Reports**: 

***
# See also:
- 


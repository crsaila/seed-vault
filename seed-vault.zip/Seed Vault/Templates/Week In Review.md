<%* await tp.file.move("Notes/Weekly/" + tp.file.title) -%>
---
tags:
- WeekInReview
saved_date: <% tp.date.now("YYYY-MM-DD") %>
updated_date: 
---
[[<% tp.date.now("gggg-[W]ww", -1, "week") %>|Last week]] | [[<% tp.date.now("gggg-[W]ww", 1, "week") %>|Next week]]
# Summary Insights


—  [[<% tp.date.weekday("gggg-MM-DD", 4) %>]]  at <% tp.date.now("HH:mm") %>
# Notes
- 

# To Do
## Done
```tasks
done
# done this week
done on <% tp.date.now("gggg-[W]ww") %>
```
# Not done
```tasks
not done
# due this week 
due on <% tp.date.now("gggg-[W]ww") %>
```
# Daily notes
- [[<% tp.date.weekday("gggg-MM-DD", 0) %>]]
- [[<% tp.date.weekday("gggg-MM-DD", 1) %>]]
- [[<% tp.date.weekday("gggg-MM-DD", 2) %>]]
- [[<% tp.date.weekday("gggg-MM-DD", 3) %>]]
- [[<% tp.date.weekday("gggg-MM-DD", 4) %>]]

***
# See also:
- 


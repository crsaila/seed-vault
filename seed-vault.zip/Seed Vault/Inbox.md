---
tags:
  - list
  - ignore
updated_date: 
---
> [!warning]- Remember
> An important thing to keep front of mind
# Projects 
## [[Project 1]]
- 
## [[Big task 1]]
- 
# Areas
## Focus 1

## Focus 2

## Focus 2

# Resources
- #tag
- [[Reference file]]
- [[MOC]]
# Also
- [[To Consider]]

***
# Archives



> [!Note]
> This document uses the [PARA Model](https://fortelabs.com/blog/para/) as a frame



